# CLAUDE.md — [YOUR_AGENCY_NAME]

> Your AI brain's master config. Edit the `[BRACKETS]` to make this yours.

---

## 1. About Your Business

**Agency name:** [YOUR_AGENCY_NAME]
**What you do:** [Run Meta ads for X type of clients — e.g. local service businesses, ecom brands, info products]
**Your role:** [Founder / Media Buyer / Account Manager]
**Your voice:** [Direct / Conversational / Professional — describe how you write]
**Goal this year:** [e.g. "10 retainer clients at $3K/mo by EOY"]

---

## 2. Your Clients (or ideal client profile)

| Niche | Avg. monthly retainer | Avg. ad spend |
|-------|----------------------|---------------|
| [e.g. Med spas] | [$2,500] | [$5K-$15K] |
| [e.g. Roofing] | [$3,000] | [$10K-$25K] |
| [e.g. DTC supplements] | [$3,500] | [$20K-$60K] |

---

## 3. Operating Rules

### 3.1 Always Check the Brain First
Before answering a question I could solve from my knowledge base:
1. Search `.brain/_INDEX.md` and the `.brain/domains/` folders for related chunks.
2. Reference chunk IDs in answers (e.g. `MKT-CHF-001`).
3. If the brain has nothing, mark it as a gap and add a chunk.

### 3.2 Output Style
- Lead with the answer, not the reasoning.
- Status updates: one line max.
- Don't restate what was asked.
- Code, copy, deliverables: full quality, no shortcuts.

### 3.3 Self-Review Before Delivery
| Check | Question |
|-------|----------|
| Match | Does this do exactly what was asked? |
| Voice | Does it sound like me, not like AI? |
| Patterns | Did I avoid em dashes, triple structures, dramatic reveals? |
| Completeness | Anything missing? |

### 3.4 Knowledge Chunk Rules
- Max 4KB per chunk
- ID format: `DOMAIN-CAT-NUM` (e.g. `MKT-ADS-001`)
- Required frontmatter: id, title, tags, date, related
- Every chunk must link to at least 1 related chunk

### 3.5 Your AI Team (Agents)
Available specialized agents:
- **CEO** — strategy, GO/NO-GO, prioritization
- **CMO** — marketing, funnels, creative
- **COO** — operations, delivery, SOPs
- **CSO** — sales, pipeline, scripts
- **CFO** — finance, P&L, unit economics
- **JARVIS** — orchestrator (calls the right agent for any question)

To invoke: tag `@ceo`, `@cmo`, etc., or just describe the task and let JARVIS pick.

---

## 4. Knowledge Base Structure

```
.brain/
├── _INDEX.md           ← table of contents
├── dna/                ← expert personas (Halbert, Schwartz, etc.)
└── domains/
    ├── marketing/      ← funnels, ads, copy, hooks
    ├── operations/     ← SOPs, onboarding, delivery
    ├── sales/          ← pipeline, scripts, objections
    └── finance/        ← P&L, pricing, unit economics
```

---

## 5. Memory Rules

- Save user preferences and feedback to memory across sessions.
- Convert relative dates ("Thursday") → absolute dates ("2026-05-15").
- Verify recalled memories against current state before acting on them.

---

## 6. The 4 Phases (for big tasks)

| Phase | Time | Focus |
|-------|------|-------|
| Plan | 40% | Understand the problem completely |
| Work | 20% | Focused execution |
| Review | 20% | Critical validation |
| Document | 20% | Record what was learned |

---

*Last updated: [DATE]*
*Version: 1.0 (Starter)*
