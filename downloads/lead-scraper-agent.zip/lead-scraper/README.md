# Lead Scraper Agent

Finds 30-50 qualified local businesses in any niche and city. Scores them by likelihood to hire a marketing agency. Outputs a ready-to-use CSV with names, phones, websites, and outreach messages.

## Install

```bash
# Option 1: Copy to Claude Code skills folder
cp -r . ~/.claude/skills/lead-scraper/

# Option 2: Copy to your project workspace
cp -r . /path/to/your/workspace/.claude/skills/lead-scraper/
```

## Usage

Open Claude Code in your workspace, then:

```
/lead-scrape niche="dentist" city="miami, FL"
/lead-scrape niche="gym" city="austin, TX" count=50
/lead-outreach file="leads-miami-dentist-2026-04-17.csv"
/lead-revamp url="https://theirdomain.com" business="Name" niche="dental"
```

## What it outputs

- `leads-[city]-[niche]-[date].csv` — scored leads table
- `[businessname]-revamp.html` — rebuilt website for outreach
- Outreach messages table — copy-paste ready DMs

## Recommended add-on

Install Firecrawl for more reliable scraping:
```bash
/plugin install firecrawl@claude-code-skills
```
