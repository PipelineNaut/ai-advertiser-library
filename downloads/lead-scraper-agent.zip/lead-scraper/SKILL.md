---
name: lead-scraper
description: Find, score, and organize qualified local business leads for outreach. Searches Google, checks Meta Ad Library, scores by likelihood to hire, outputs CSV. Use when finding prospects for a marketing agency.
---

# Lead Scraper Skill

## Slash Command Usage

```
/lead-scrape niche="dentist" city="miami, FL" count=30
/lead-scrape niche="gym" city="austin, TX"
/lead-scrape niche="plumber" city="dallas, TX" count=50 min_rating=4.5
```

## Workflow

### Step 1: Search for businesses
Search Google for "[niche] businesses in [city, state]". Collect at minimum:
- Business name
- Phone number (from Google listing)
- Website URL
- Google rating
- Number of reviews
- Address

### Step 2: Check Meta Ad Library
For each business with a website, search `facebook.com/ads/library` for their business name or domain:
- Are they running active ads? (yes/no)
- How many active ads?
- Do the ads look professional or amateur?

### Step 3: Score each lead (1-5)
Use the scoring criteria from CLAUDE.md.

### Step 4: Filter
Remove any businesses:
- Under 4.0 stars
- Under 20 reviews
- No phone number available
- Permanently closed

### Step 5: Sort
Sort by score descending, then by review count descending.

### Step 6: Output
1. Print a markdown table with columns: Name | Phone | Website | Rating | Reviews | Running Ads | Score | Notes
2. Save as `leads-[city]-[niche]-[YYYY-MM-DD].csv`

## Outreach Generator

Run after you have a leads CSV:

```
/lead-outreach file="leads-miami-dentist-2026-04-17.csv"
```

For each lead, generate a 2-3 sentence personalized DM that:
- References something specific about their business (their niche, location, or gap you noticed)
- Points out ONE specific opportunity (no ads, bad website, low review response rate)
- Ends with a soft ask ("would love to show you what this could look like for [business name]")

Output as table: Business Name | Platform (Instagram/Email/SMS) | Outreach Message

## Website Revamp

```
/lead-revamp url="https://uglydentistsite.com" business="Miami Smiles Dental" niche="dental" city="miami"
```

Scrapes the existing site for real info, then builds a complete modern HTML landing page. Saves as `[businessname]-revamp.html`.

## Firecrawl Integration (Recommended)
If Firecrawl is installed, use it for more reliable scraping:
```
Use Firecrawl to scrape business listings instead of direct Google search for better results on JavaScript-rendered pages.
```
