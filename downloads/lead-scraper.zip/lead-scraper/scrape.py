#!/usr/bin/env python3
"""
Lead Scraper for Ad Agencies
Finds local businesses, checks their Meta ad status, scores them, and exports to Google Sheets.

Usage:
  python scrape.py "dentists" "Tampa, FL"
  python scrape.py "HVAC companies" "Phoenix, AZ"
  python scrape.py "med spas" "Miami, FL"
"""

import csv
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

# Optional: Google Sheets integration
try:
    import gspread
    from google.oauth2.service_account import Credentials
    SHEETS_AVAILABLE = True
except ImportError:
    SHEETS_AVAILABLE = False

# Optional: Web search
try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False


# ═══════════════════════════════════════
# CONFIGURATION — Edit these values
# ═══════════════════════════════════════

CONFIG = {
    # Google Sheets settings
    "google_sheet_id": "",  # Paste your Google Sheet ID here
    "credentials_file": "credentials.json",  # Your Google service account key file

    # Scraping settings
    "max_results": 50,
    "min_rating": 3.5,
    "min_reviews": 20,
    "delay_between_searches": 2,  # seconds between requests (be respectful)

    # Scoring thresholds
    "score_5_keywords": ["boost post", "low quality", "stock photo", "blurry", "no cta"],
    "score_4_keywords": ["decent", "professional", "running"],
}

PROSPECTS_DIR = Path(__file__).parent / "prospects"
PROSPECTS_DIR.mkdir(exist_ok=True)


def score_prospect(has_facebook, running_ads, ad_count, ad_quality, rating, reviews):
    """Score a prospect 1-5 based on their ad status and online presence."""
    if running_ads and ad_quality in ("bad", "low"):
        return 5  # Running bad ads = easiest to close
    if running_ads and ad_quality in ("decent", "good"):
        return 4  # Running decent ads = might want better
    if has_facebook and not running_ads:
        return 3  # Facebook page but no ads
    if not has_facebook and rating >= 3.5 and reviews >= 20:
        return 2  # No Facebook but good business
    return 1  # No online presence


def search_businesses(niche, city, max_results=50):
    """
    Search for businesses. This is a template that Claude Code will enhance
    with actual web search capabilities when the student runs it.

    The student pastes this into Claude Code and says:
    "Make the search_businesses function actually search the web for real businesses"
    """
    print(f"\n🔍 Searching for {max_results} {niche} in {city}...")
    print("   (Claude Code will enhance this with real web search)")

    # Placeholder results — Claude Code replaces this with real search
    # When you open this project in Claude Code, tell it:
    # "Make search_businesses actually search Google for real businesses"
    sample_businesses = []
    for i in range(min(5, max_results)):
        sample_businesses.append({
            "name": f"Sample {niche.title()} Business {i+1}",
            "phone": "(555) 000-0000",
            "website": f"https://example{i+1}.com",
            "address": f"123 Main St #{i+1}, {city}",
            "rating": 4.5,
            "reviews": 50 + i * 10,
            "has_facebook": True,
            "running_ads": i % 2 == 0,
            "ad_count": 3 if i % 2 == 0 else 0,
            "ad_quality": "bad" if i == 0 else "decent" if i % 2 == 0 else "none",
        })

    return sample_businesses


def check_meta_ads(business_name):
    """
    Check Meta Ad Library for a business.
    Claude Code will enhance this with actual Ad Library checking.
    """
    # Placeholder — Claude Code replaces with real Ad Library check
    return {"running_ads": False, "ad_count": 0, "ad_quality": "unknown"}


def export_to_csv(prospects, niche, city):
    """Save prospects to a local CSV file."""
    date_str = datetime.now().strftime("%Y-%m-%d")
    safe_city = city.replace(",", "").replace(" ", "-").lower()
    safe_niche = niche.replace(" ", "-").lower()
    filename = PROSPECTS_DIR / f"{safe_city}-{safe_niche}-{date_str}.csv"

    headers = [
        "Score", "Business Name", "Phone", "Website", "Address",
        "Rating", "Reviews", "Facebook Page", "Running Ads",
        "Number of Ads", "Ad Quality Notes",
        "Outreach Date", "Response", "Notes", "Follow-Up Date"
    ]

    with open(filename, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for p in prospects:
            writer.writerow([
                p["score"],
                p["name"],
                p["phone"],
                p["website"],
                p["address"],
                p["rating"],
                p["reviews"],
                "Yes" if p["has_facebook"] else "No",
                "Yes" if p["running_ads"] else "No",
                p["ad_count"],
                p["ad_quality"],
                "", "", "", ""  # Empty tracking columns
            ])

    print(f"\n💾 Saved to {filename}")
    return filename


def export_to_sheets(prospects, niche, city):
    """Push prospects to Google Sheets."""
    if not SHEETS_AVAILABLE:
        print("\n⚠️  Google Sheets not available. Install with: pip install gspread google-auth")
        return None

    sheet_id = CONFIG["google_sheet_id"]
    creds_file = CONFIG["credentials_file"]

    if not sheet_id:
        print("\n⚠️  No Google Sheet ID configured. Edit CONFIG in scrape.py")
        return None

    if not os.path.exists(creds_file):
        print(f"\n⚠️  Credentials file not found: {creds_file}")
        print("   Follow the README to set up Google Sheets API credentials.")
        return None

    try:
        scopes = [
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive"
        ]
        creds = Credentials.from_service_account_file(creds_file, scopes=scopes)
        gc = gspread.authorize(creds)
        sh = gc.open_by_key(sheet_id)

        # Create new tab
        date_str = datetime.now().strftime("%Y-%m-%d")
        tab_name = f"{city} - {niche.title()} - {date_str}"

        try:
            worksheet = sh.add_worksheet(title=tab_name, rows=len(prospects) + 5, cols=15)
        except Exception:
            # Tab might already exist
            worksheet = sh.worksheet(tab_name)
            worksheet.clear()

        # Headers
        headers = [
            "Score", "Business Name", "Phone", "Website", "Address",
            "Rating", "Reviews", "Facebook Page", "Running Ads",
            "# of Ads", "Ad Quality",
            "Outreach Date", "Response", "Notes", "Follow-Up Date"
        ]

        # Build all rows
        rows = [headers]
        for p in prospects:
            rows.append([
                p["score"],
                p["name"],
                p["phone"],
                p["website"],
                p["address"],
                p["rating"],
                p["reviews"],
                "Yes" if p["has_facebook"] else "No",
                "Yes" if p["running_ads"] else "No",
                p["ad_count"],
                p["ad_quality"],
                "", "", "", ""
            ])

        worksheet.update(rows, value_input_option="RAW")

        # Format header row
        worksheet.format("A1:O1", {
            "textFormat": {"bold": True},
            "backgroundColor": {"red": 0.85, "green": 0.92, "blue": 1.0}
        })

        # Freeze header row
        worksheet.freeze(rows=1)

        print(f"\n📊 Pushed to Google Sheets: tab '{tab_name}'")
        return tab_name

    except Exception as e:
        print(f"\n❌ Google Sheets error: {e}")
        print("   CSV backup was still saved locally.")
        return None


def main():
    if len(sys.argv) < 3:
        print("Usage: python scrape.py \"niche\" \"city, state\"")
        print("Example: python scrape.py \"dentists\" \"Tampa, FL\"")
        sys.exit(1)

    niche = sys.argv[1]
    city = sys.argv[2]

    print(f"""
╔══════════════════════════════════════╗
║     LEAD SCRAPER FOR AD AGENCIES     ║
╚══════════════════════════════════════╝

  Niche: {niche}
  City:  {city}
  Max:   {CONFIG['max_results']} businesses
  Min:   {CONFIG['min_rating']}⭐ / {CONFIG['min_reviews']} reviews
""")

    # Search for businesses
    businesses = search_businesses(niche, city, CONFIG["max_results"])

    # Score and filter
    prospects = []
    for b in businesses:
        score = score_prospect(
            b.get("has_facebook", False),
            b.get("running_ads", False),
            b.get("ad_count", 0),
            b.get("ad_quality", "none"),
            b.get("rating", 0),
            b.get("reviews", 0)
        )

        if b["rating"] >= CONFIG["min_rating"] and b["reviews"] >= CONFIG["min_reviews"]:
            b["score"] = score
            prospects.append(b)

    # Sort by score (desc), then rating (desc)
    prospects.sort(key=lambda x: (-x["score"], -x["rating"]))

    print(f"\n✅ Found {len(prospects)} qualified prospects")

    # Show score breakdown
    scores = {}
    for p in prospects:
        scores[p["score"]] = scores.get(p["score"], 0) + 1
    for s in sorted(scores.keys(), reverse=True):
        labels = {5: "Bad ads (easiest)", 4: "Decent ads", 3: "FB, no ads", 2: "No FB, good biz", 1: "Skip"}
        print(f"   Score {s}: {scores[s]} prospects — {labels.get(s, '')}")

    # Export
    csv_file = export_to_csv(prospects, niche, city)
    export_to_sheets(prospects, niche, city)

    print(f"""
╔══════════════════════════════════════╗
║              DONE! ✅                ║
╠══════════════════════════════════════╣
║  {len(prospects):3d} prospects found and scored      ║
║  CSV saved to prospects/ folder      ║
║                                      ║
║  Next: Open your Google Sheet and    ║
║  start outreaching Score 5s first!   ║
╚══════════════════════════════════════╝
""")


if __name__ == "__main__":
    main()
