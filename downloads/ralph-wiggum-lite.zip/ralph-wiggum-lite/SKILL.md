---
name: ralph-wiggum-lite
description: Iterative copy verification loop. Forces AI-generated copy through 8 framework passes until it scores 9.5+. Named after the Simpsons character who repeats things until they stick. Triggers - "ralph wiggum", "verify copy", "copy quality", "8-pass loop", "polish copy".
allowed-tools: Read, Write, Edit, WebFetch
---

# RALPH WIGGUM LITE — 8-Pass Copy Verification Loop

## The Idea

Most AI copy is 6/10 quality. Good enough to look like work, not good enough to convert. The Ralph Wiggum technique forces the same copy through 8 framework passes. After each pass, the copy gets stronger. By pass 8, it's 9.5+.

It's named after Ralph Wiggum from the Simpsons, who repeats things until they stick. Same energy.

---

## Why You Need This

You wrote a sales email. It looks fine. You ship it. It does 1.2% conversion.

You should have run it through Ralph. Pass 1 catches the weak hook. Pass 3 catches the missing proof. Pass 5 catches the rhythm break. Pass 7 makes you cut 30% of the words.

Same email, after Ralph: 3.8% conversion.

That's the difference between "good enough" copy and copy that actually pays you.

---

## The 8 Passes

### Pass 1: Schwartz Awareness Check
**Question:** Is this written for the right awareness level?
**Look for:** Are we leading with the problem (unaware audience) or the offer (most-aware audience)? Mismatch kills conversion.
**Fix:** Adjust the opening to match where the audience actually is.

### Pass 2: Hook Strength Check
**Question:** Does the first line stop the scroll?
**Look for:** Is the first sentence boring, generic, or marketer-y? Would you keep reading if you didn't have to?
**Fix:** Rewrite the first line until you can read it cold and want to know more.

### Pass 3: Specificity Check
**Question:** Have I replaced every vague word with a specific one?
**Look for:** "Many", "soon", "growth", "results", "transformation". These are placeholders for laziness.
**Fix:** Swap "many" for "73%". "Soon" for "by Friday." "Growth" for "+$8K MRR."

### Pass 4: Proof Check
**Question:** Does every claim have a number, name, or example next to it?
**Look for:** Claims that sound like marketing, not reporting.
**Fix:** Add the proof. If you can't, cut the claim.

### Pass 5: Voice Check
**Question:** Does this sound like a human or like AI?
**Look for:** Em dashes. Triple structures ("It's not X, it's Y, it's Z"). Perfect symmetry. Corporate words like "leverage", "robust", "seamless", "utilize".
**Fix:** Read out loud. Where you stumble or sound robotic, rewrite.

### Pass 6: Pace Check
**Question:** Does the rhythm work?
**Look for:** Long sentence after long sentence. No breath. No white space.
**Fix:** Mix sentence length. Use fragments. Use line breaks. Make it scannable.

### Pass 7: Cut Check
**Question:** Can I cut 20% without losing meaning?
**Look for:** Adjectives, qualifiers, throat-clearing intros, redundant transitions.
**Fix:** Cut. If it doesn't change the meaning, it was filler.

### Pass 8: Cold Read Test
**Question:** If I read this fresh, would I act on it?
**Look for:** The whole piece, not the parts. Does it flow? Does it land? Does it close?
**Fix:** If anything feels off, you're not done. Loop back to whichever pass missed.

---

## How To Run It

Paste this into Claude after writing initial copy:

```
You are Ralph Wiggum. Run the 8-pass copy verification loop on the copy below.

For each pass:
1. Quote the SPECIFIC line(s) that fail the pass
2. Explain WHY they fail
3. Rewrite them
4. Move to the next pass

After all 8 passes, output the final polished version. Score it 1-10.
If under 9.5, run pass 1-8 again on the polished version.
Stop when score hits 9.5 or above.

Voice rules to enforce:
- No em dashes
- No triple structures (X. Y. Z. patterns)
- No corporate words (leverage, utilize, optimize, seamless, robust)
- No "AI tells" (perfect symmetry, predictable transitions)
- Short sentences. Fragments allowed. White space respected.

Copy to verify:

[paste your draft here]
```

---

## When To Use Ralph

Use Ralph for:
- Sales emails (especially launch emails)
- Long-form ad copy
- Landing page headlines and bullets
- VSL scripts
- Any copy where 0.5% conversion difference = real money

Don't use Ralph for:
- Quick chat replies
- Internal Slack messages
- Documentation
- Anywhere copy quality doesn't drive revenue

---

## What This Costs You

Time. Each pass adds 1-3 minutes. 8 passes = 8-25 minutes per piece.

Most people won't do this. They'll write copy in 5 minutes and ship it. That's why most copy is mediocre.

You'll do it. Your copy will hit. Your campaigns will print.

---

## The Quality Bar

A piece that's been through Ralph should:
- Have a hook that makes someone want to keep reading
- Use specific numbers, names, and examples for every claim
- Read like a human texted a friend, not like a brand wrote a memo
- Land an emotional or logical punch every 2-3 lines
- End with a clear, scannable call to action

If your draft doesn't hit all 5, run another pass.

---

*Ralph Wiggum Lite v1.0. The full Ralph loop has 12 passes including a Bencivenga validation suite and a believability gauntlet. Master the 8-pass version first.*
