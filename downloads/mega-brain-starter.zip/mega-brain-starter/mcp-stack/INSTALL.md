# 🔌 MCP Stack — The Tools That Make Your AI Useful

> MCPs (Model Context Protocol servers) are how your AI talks to external tools. Without them, Claude can think but can't DO anything outside the chat. With them, Claude can run ads, scrape websites, automate browsers, and pull data on demand.

---

## What An MCP Actually Is

Think of an MCP as a USB port for your AI. Every MCP plugs in a new capability.

- **Meta Ads MCP** = lets Claude run, audit, and optimize Meta campaigns
- **Firecrawl MCP** = lets Claude scrape any website at scale
- **Playwright MCP** = lets Claude control a real browser

You install the MCP. You wire it into Claude's settings. Now Claude has new tools.

---

## The 3 MCPs Every Agency Needs

### 1. Meta Ads MCP (the official one)

**What it does:** Claude can pull ad performance data, audit campaigns, suggest optimizations, even build new campaigns. All without you opening Ads Manager.

**Why agencies need it:** This is the difference between Claude saying "check your CPA" and Claude saying "your CPA on Campaign X is $42, target is $30, here's what to kill and what to scale." Real data, real recommendations.

**The big news:** Meta launched the official MCP on April 29, 2026. It has 29 tools, uses OAuth (no Dev App headaches), and works in Claude Desktop and Claude Code.

**Install:**
```bash
npm install -g @meta/ads-mcp-server
```

Then add to your `~/.claude/settings.json`:
```json
{
  "mcpServers": {
    "meta-ads": {
      "command": "npx",
      "args": ["-y", "@meta/ads-mcp-server"],
      "env": {
        "META_ACCESS_TOKEN": "your-token-here"
      }
    }
  }
}
```

**First time setup:** Run `meta-ads-mcp auth` and follow the OAuth flow. It'll store your token securely.

**What you can ask Claude after install:**
- "audit my account 1234567890 for the last 30 days"
- "which campaigns have CPA above target this week?"
- "show me my top 5 ads by ROAS in the [client] account"

---

### 2. Firecrawl MCP

**What it does:** Claude can scrape any website at scale. One URL, multiple URLs, entire sites. Returns clean markdown ready to feed into research, copy, or competitive analysis.

**Why agencies need it:** Voice-of-customer research used to take days. With Firecrawl, you scrape Reddit, Amazon, and competitor sites in minutes. Your ad copy stops sounding AI because you're feeding it real customer language.

**Install:**
```bash
npm install -g firecrawl-mcp
```

Get a free API key at firecrawl.dev. Then add to settings:
```json
{
  "mcpServers": {
    "firecrawl": {
      "command": "npx",
      "args": ["-y", "firecrawl-mcp"],
      "env": {
        "FIRECRAWL_API_KEY": "fc-xxxxxxxxxxxxx"
      }
    }
  }
}
```

**What you can ask Claude after install:**
- "scrape r/[subreddit]/top of all time and pull pain language"
- "scrape these 5 competitor landing pages and tell me what hooks they use"
- "scrape the Amazon reviews on [product URL], categorize objections"

---

### 3. Playwright MCP

**What it does:** Claude can control a real browser. Click buttons, fill forms, take screenshots, navigate sites that block scrapers.

**Why agencies need it:** Some things you can't do with HTTP scraping. Logging into Meta Ads Library and exporting data. Auto-creating Framer pages from Figma designs. Taking screenshot proof for client reports. Playwright handles all of it.

**Install:**
```bash
npm install -g @playwright/mcp
npx playwright install chromium
```

Then add to settings:
```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp"]
    }
  }
}
```

**What you can ask Claude after install:**
- "open meta ad library, search [brand], take screenshots of top 10 active ads"
- "go to [Framer site], log in, create a new page from this design"
- "test the checkout flow on [client site] and screenshot any errors"

---

## Bonus MCPs Worth Knowing

| MCP | What It Does | When To Add It |
|-----|--------------|----------------|
| **Chroma** | Talk to your vector database | If you're doing custom memory or knowledge work |
| **Google Drive** | Read/write Google Docs, Sheets | If client deliverables live in Drive |
| **Slack** | Read/post in Slack channels | If your team lives in Slack |
| **Notion** | Read/write Notion pages | If clients use Notion for project tracking |
| **Stripe** | Pull billing data | If you want Claude to track revenue |

---

## Combining MCPs (the real magic)

Single MCPs are powerful. Combined MCPs are dangerous.

**Example combo: Meta Ads + Firecrawl + Playwright**
> *"Find competitor brands ranking for 'cold plunge' in Meta Ad Library. Pull their top 5 ads. Scrape their landing pages. Screenshot their checkout flow. Compare to our client's setup."*

That's a $5K research project. Done in 10 minutes. By Claude. While you do something else.

---

## Settings.json Template

Drop this into `~/.claude/settings.json` to wire all 3 MCPs at once:

```json
{
  "mcpServers": {
    "meta-ads": {
      "command": "npx",
      "args": ["-y", "@meta/ads-mcp-server"],
      "env": {
        "META_ACCESS_TOKEN": "your-token-here"
      }
    },
    "firecrawl": {
      "command": "npx",
      "args": ["-y", "firecrawl-mcp"],
      "env": {
        "FIRECRAWL_API_KEY": "fc-xxxxxxxxxxxxx"
      }
    },
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp"]
    }
  }
}
```

Replace the placeholder tokens with your real ones. Restart Claude. You're loaded.

---

## Common Issues

**MCP not showing up:** restart Claude Code/Desktop after editing settings.json.

**Authentication errors:** for Meta Ads MCP, your OAuth token expires every 60 days. Re-auth with `meta-ads-mcp auth`.

**Rate limits:** Firecrawl free tier = 500 pages/month. If you hit the limit, upgrade or batch your scraping into fewer sessions.

**Playwright won't open:** make sure Chromium installed: `npx playwright install chromium`.

---

## What This Unlocks

Once these 3 MCPs are running, you stop being a media buyer who uses AI. You become a media buyer with an AI agency working for you 24/7.

That's the unlock.

---

*MCP Stack v1.0. Add more MCPs as you find them. mcp.so has a directory of every public MCP.*
