# 🧠 MEGA BRAIN STARTER — Install Guide

> Your starter pack to build an AI brain for your agency. Clone, customize, ship.

---

## What's In This Pack

```
mega-brain-starter/
├── CLAUDE.md                         ← master config (edit first)
├── .claude/
│   ├── agents/
│   │   ├── ceo.md                    ← strategic decisions
│   │   ├── cmo.md                    ← marketing & ads
│   │   ├── coo.md                    ← operations & SOPs
│   │   ├── cso.md                    ← sales & closing
│   │   ├── cfo.md                    ← finance & P&L
│   │   └── jarvis.md                 ← orchestrator
│   └── skills/
│       ├── mega-digestive-lite/      ← knowledge digestion pipeline
│       ├── firecrawl-research-lite/  ← voice-of-customer research
│       └── copywriter-lite/          ← 4-master copywriting
└── .brain/
    ├── _INDEX.md                     ← table of contents
    ├── domains/                      ← knowledge chunks by category
    │   ├── marketing/MKT-ADS-001.md  ← example chunk
    │   └── operations/OPS-ONB-001.md ← example chunk
    └── dna/halbert.md                ← example expert persona
```

---

## Setup (Takes 15 Minutes)

### Step 1: Place the folder
Copy `mega-brain-starter` to your project root. Rename it to your agency:
```bash
mv mega-brain-starter [your-agency-name]
cd [your-agency-name]
```

### Step 2: Customize the CLAUDE.md
Open `CLAUDE.md`. Replace every `[BRACKET]` with your real info:
- Agency name
- What you do
- Your voice
- Your goal this year
- Your client niches

This file is the single source of truth your AI reads every session.

### Step 3: Customize the agents
Open each file in `.claude/agents/`. Replace `[YOUR_AGENCY_NAME]` with your real name. Adjust the mission and responsibilities to fit your business.

You don't need to use all 6 agents on Day 1. Start with CMO and JARVIS. Add the rest as needed.

### Step 4: Add your first chunk
Read the example chunks in `.brain/domains/`. Then add ONE chunk of real knowledge from your business. Could be:
- Your top-performing ad framework
- Your client onboarding process
- Your pricing logic

That's your first piece of permanent knowledge.

### Step 5: Test it
Open Claude Code in your project folder. Ask:
> *"Read CLAUDE.md and tell me what you understand about my business."*

If the response captures your business correctly, you're set up.

---

## How To Use Daily

### Morning: ask JARVIS
Drop a question. JARVIS routes to the right agent:
- "Should I take this new client?" → CEO
- "Write me 5 ad hooks for [niche]" → CMO + Copywriter
- "What's my margin per client?" → CFO

### Throughout the day: feed the brain
When you learn something valuable, add it as a chunk:
- New ad framework that worked
- New objection from a sales call
- New SOP that emerged

Use the chunk format from the examples.

### Weekly: digest new knowledge
When you finish a course, watch a webinar, or read a book — run it through MEGA DIGESTIVE LITE (3 phases). Output goes into your brain forever.

---

## Files You Should Edit First

In order:
1. `CLAUDE.md` (mandatory, do this first)
2. `.claude/agents/cmo.md` (start here for ads work)
3. `.claude/agents/jarvis.md` (the orchestrator)
4. Add 3-5 chunks of YOUR own knowledge to `.brain/domains/`

---

## Files You Probably Won't Need On Day 1

- All 6 agents (you might only use 2-3)
- DNA personas (build them as you digest experts)
- MEGA DIGESTIVE skill (you'll use it once you have raw content to process)

---

## Common Questions

**Q: Do I need Claude Code or does this work in Claude.ai?**
The CLAUDE.md and agents work best in Claude Code (the CLI/desktop app). The skills work in either. The .brain/ chunks are just markdown files — they work anywhere.

**Q: How big should my brain get?**
Start with 10 chunks. Aim for 100 by month 3. Quality matters more than count.

**Q: Should I commit this to git?**
Yes. Your brain is your IP. Version control it.

**Q: Can my team use the same brain?**
Yes. Share the repo. Everyone gets the same agents and knowledge.

**Q: What's the difference between this and a Notion doc?**
Notion is passive (you read it). This is active (your AI reads it for you and uses it to answer your questions).

---

## What's Next

Once this is running:
1. Add 1 chunk per day to your brain
2. After 30 days, you'll have 30 pieces of permanent knowledge
3. After 90 days, your AI knows your business better than your last hire did

That's the compound. Show up, feed the brain, let it pay you back forever.

---

*Starter Pack v1.0. Built from a real production agency brain. The full version has more agents, more skills, and more sophisticated workflows. Master this version first.*
