---
name: mega-digestive-lite
description: Simplified 3-phase knowledge digestion pipeline. Turn raw content (transcripts, PDFs, books, recordings) into structured knowledge chunks ready for your brain. Triggers - "digest", "process knowledge", "ingest", "chunk this".
allowed-tools: Read, Write, Edit, Glob, Grep, TodoWrite, Bash
---

# MEGA DIGESTIVE LITE — 3-Phase Knowledge Pipeline

## What This Does

Take raw content (transcripts, PDFs, books, training videos, course material) and turn it into structured, searchable knowledge chunks that your AI agents can use forever.

Think of it as your "training data factory." Drop content in, get usable knowledge out.

## When To Use

- You bought a course and want the full knowledge in your brain
- You watched a webinar with gold and want to keep it
- You found an article worth saving permanently
- You have meeting transcripts to mine for insights
- You're building a knowledge base from scratch

## The 3 Phases

```
INPUT                PROCESSING              OUTPUT
─────                ──────────              ──────
raw/        →        chunks/         →       brain/
(messy)              (structured)            (searchable)
```

---

## PHASE 1: INGEST

**Goal:** get the raw content into the system.

**Steps:**
1. Drop files into `.brain/raw/` (PDFs, transcripts, .md, .txt all work).
2. Tag each file with: source, date, topic. Example filename: `2026-05-08_jeremy-haynes_challenge-funnel.md`
3. If it's a YouTube video, paste the transcript as a `.md` file.
4. If it's a PDF longer than 100 pages, split it into chapters first.

**What success looks like:**
- All raw files in `.brain/raw/`
- Filenames follow the pattern: `YYYY-MM-DD_source_topic.md`
- No file larger than 50 pages

---

## PHASE 2: CHUNK

**Goal:** break raw content into 4KB semantic chunks.

**For each raw file, instruct the AI:**

> *"Read [filepath]. Break it into knowledge chunks of max 4KB each. Each chunk must:*
> *1. Cover ONE complete idea (don't split mid-thought)*
> *2. Have an ID like DOMAIN-CAT-NUM (e.g., MKT-FUN-001 for Marketing/Funnel/001)*
> *3. Have a title that summarizes the idea in 5 words*
> *4. Have YAML frontmatter with: id, title, tags, date, source, related*
> *5. Link to at least 1 related chunk via `related:` field"*

**Domain codes (customize for your business):**
- `MKT` — Marketing
- `OPS` — Operations  
- `SAL` — Sales
- `FIN` — Finance
- `LED` — Leadership/Strategy
- `DES` — Design

**Category codes (under each domain):**
- `MKT-CHF` = Challenge Funnels
- `MKT-WEB` = Webinars
- `MKT-ADS` = Ads/Creative
- `MKT-COP` = Copywriting
- `OPS-SOP` = SOPs
- `OPS-ONB` = Onboarding

**Example chunk:**

```markdown
---
id: MKT-CHF-001
title: 3-Day Challenge Show-Up Rate
tags: [challenge, funnel, retention]
date: 2026-05-08
source: Jeremy Haynes (transcript)
related: [MKT-CHF-002, MKT-CHF-005]
---

# 3-Day Challenge Show-Up Rate

The biggest leak in challenge funnels isn't conversion. It's show rate. 
A 60% show rate on Day 1 drops to 35% on Day 2 and 18% on Day 3 if 
you don't actively pull people back.

The fix:
1. SMS at 9am the morning of each day
2. WhatsApp message in the group at 10am
3. Personal DM from the host to top engagers
4. Public callout in the group of who's "in" today

Brands that hit 50%+ show rate on Day 3 use ALL FOUR. Brands that 
hit 18% use one or none.
```

**What success looks like:**
- Every raw file produces 5-30 chunks
- Each chunk is under 4KB
- Each chunk has frontmatter and at least 1 `related:` link
- Chunks live in `.brain/domains/[domain]/[category]/`

---

## PHASE 3: SYNTHESIZE

**Goal:** turn chunks into actionable artifacts.

After chunking, run synthesis on the chunks. Pick one of these synthesis types:

### A) Topic Dossier
A 2-3 page master document on one topic, citing all related chunks.

> *"Read all chunks tagged [topic]. Synthesize into a dossier covering: the core principle, the 3-5 key tactics, the common mistakes, the metrics that matter, and the 'how to start tomorrow' section. Cite chunk IDs in brackets like [MKT-CHF-001]."*

### B) Expert DNA
A persona file capturing how a specific expert thinks. Use for high-value masters whose work you've digested.

> *"Read all chunks from [expert name]. Build a DNA file covering: their core thesis, their unique frameworks, their language patterns, their controversial takes, what they hate, and what they always recommend. Output as `.brain/dna/[expert-name].md`."*

### C) Decision Tree
A flowchart of "if this, then that" rules pulled from the source.

> *"From the chunks, extract every conditional rule (if/when/whenever). Output as a decision tree in markdown."*

**What success looks like:**
- At least 1 dossier per major topic
- At least 1 DNA file per expert digested
- Synthesis files live in `.brain/synthesis/`

---

## How To Use This Skill

In any session, paste this prompt:

> *"Run the mega-digestive-lite pipeline on `.brain/raw/[filename]`. Use Phase 1, 2, and 3. Output chunks to `.brain/domains/` and synthesis to `.brain/synthesis/`."*

The AI will read this skill file and execute the 3 phases.

---

## Quality Bar

A chunk is good when:
- A new agent could read it and understand the idea without context
- It cites the original source
- It links to at least 1 related chunk
- It's under 4KB

If a chunk fails any of these, redo it.

---

## What This Is NOT

- Not a transcription tool. Bring transcripts in.
- Not a search engine. It produces chunks; you query them separately.
- Not real-time. Run it as a batch process when you've got new content to digest.

---

*MEGA DIGESTIVE LITE v1.0 — Starter version. The full system has 10 phases including entity resolution, cross-source aggregation, and automatic agent enrichment. Master this lite version first.*
