---
name: firecrawl-research-lite
description: Voice-of-customer mining via web scraping. Pull real customer language from Reddit, Amazon reviews, YouTube comments, forums, and competitor sites for ad copy. Triggers - "research", "voice of customer", "VOC", "scrape reviews", "competitor research".
allowed-tools: WebFetch, WebSearch, Read, Write, Edit
---

# FIRECRAWL RESEARCH LITE

## What This Does

Mine the internet for real customer language. Reddit threads, Amazon reviews, YouTube comments, forum posts, competitor sites. Convert what real humans say into ad copy material.

This is the work that separates good copy from AI-flavored copy.

## When To Use

- Writing ads in a niche you don't deeply know
- Finding pain language (the words customers use, not what marketers think)
- Stealing winning angles from competitor ads
- Building a swipe file for any market
- Researching a new client's audience before writing copy

---

## The 4 Sources To Mine

### 1. Reddit (gold for emotional language)
- Subreddits where the audience hangs out
- Look for: complaints, "hot takes," confessions
- Best query patterns:
  - `[product] doesn't work` → reveals failure language
  - `[product] changed my life` → reveals transformation language
  - `why does [problem] happen` → reveals confusion / education gaps

### 2. Amazon Reviews (gold for objections + benefits)
- Sort 1-star reviews → reveals deal-breakers
- Sort 5-star reviews → reveals "the moment it clicked"
- Best filters: "Verified Purchase," sort by helpful

### 3. YouTube Comments (gold for credibility cues)
- Top videos in your niche
- Look for: "Same here, X happened to me"
- Pull comments with 50+ likes (validation signal)

### 4. Competitor Pages + Ads (gold for proven angles)
- Their landing pages: pull headlines, bullets, CTAs
- Their Meta Ad Library: what's running 60+ days
- Their reviews/testimonial pages: real customer phrases

---

## The Master Research Prompt

Use this prompt with web-fetching enabled:

```
You are a research analyst. Your job is to extract real customer language 
from the URLs I give you. Output exactly this structure:

URL: [the source URL]

PAIN LANGUAGE (5 phrases customers use to describe the problem):
1. [exact quote, in their words]
2. ...

DREAM OUTCOME (5 phrases describing the after-state):
1. [exact quote]
2. ...

OBJECTIONS (3 reasons people don't buy or didn't):
1. [exact quote]
2. ...

UNEXPECTED INSIGHTS (anything surprising — emotions, identity claims, 
specific events, weird behaviors):
1. ...

DO NOT paraphrase. Use exact quotes wherever possible. Mark paraphrased 
material with [PARA].
```

---

## Output Structure

After running research, save it to your brain as a chunk:

```markdown
---
id: VOC-[NICHE]-001
title: [Niche] Voice of Customer Research
tags: [voc, research, niche-name]
date: [YYYY-MM-DD]
sources: [list of URLs]
related: [related chunks]
---

# Pain Language
[exact quotes]

# Dream Outcome  
[exact quotes]

# Objections
[exact quotes]

# Insights
[surprising patterns]
```

Save under `.brain/voc/[niche]-voc-001.md`.

---

## Rule

**Never write ad copy without 30 minutes of VOC research first.** 

That's the difference between copy that sounds AI and copy that sounds like a real customer. Skip this step and your hooks will be generic.

---

*Firecrawl Lite v1.0 — Manual web-fetch version. Upgrade to Firecrawl MCP for batch scraping.*
