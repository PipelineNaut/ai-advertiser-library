---
name: copywriter-lite
description: Direct response copywriter using a unified 4-master system (Schwartz strategy, Georgi structure, Halbert hooks, Bencivenga validation). Use for ads, VSLs, sales pages, emails, headlines. Triggers - "write copy", "VSL", "sales letter", "ad copy", "headlines", "emails".
allowed-tools: Read, Write, Edit, WebFetch, WebSearch
---

# COPYWRITER LITE

## What This Does

Write direct response copy using a 4-step process that combines the best of four legendary copywriters. Strategic angle (Schwartz) → research (Georgi) → tactical hooks (Halbert) → final validation (Bencivenga).

Skip steps and you'll write AI-flavored copy. Follow them and you'll write copy that converts.

---

## The 4-Step Process

### Step 1: SCHWARTZ — Pick the Awareness Level

Before writing a single word, identify which awareness level your audience is at:

| Level | They know... | Hook strategy |
|-------|--------------|---------------|
| **Unaware** | Nothing about the problem | Lead with the problem |
| **Problem Aware** | The problem, not solutions | Lead with agitation |
| **Solution Aware** | Solutions exist, not yours | Lead with mechanism |
| **Product Aware** | Your product, not yet sold | Lead with proof |
| **Most Aware** | They want to buy now | Lead with offer |

**Output:** "Audience is at [level]. Hook strategy = [strategy]."

### Step 2: GEORGI — Research the RMBC

Before drafting, fill in 4 fields (RMBC = Research, Market, Big Idea, Concept):

- **R - Research:** What did real customers say? (use VOC research)
- **M - Market:** Who exactly is this for? Niche, age, situation, pain.
- **B - Big Idea:** What's the ONE idea that makes them stop and say "wait, what"?
- **C - Concept:** What's the angle that delivers the big idea? (e.g., "the hidden hormone everyone misses")

**Output:** Filled-in RMBC. If any field is empty, stop and research more.

### Step 3: HALBERT — Write Hooks Like a Direct Mail Killer

Halbert wrote like he was writing to one person. Apply 3 rules:

1. **Talk like a friend, not a marketer.** Use contractions. Use fragments. Use "you" 3x more than "we."
2. **Lead with conflict, not benefits.** "Your dentist hates this" beats "5 ways to whiten teeth."
3. **One sentence per line.** White space is a weapon.

**Hook templates Halbert used:**
- "Here's something most [niche] people will never tell you..."
- "[Authority figure] hates this. But you'll love it."
- "I almost didn't write this. Here's why I had to."
- "Look, I'll be honest..."
- "If you've tried [common solution] and it didn't work, this is for you."

### Step 4: BENCIVENGA — Validate

Before shipping, run 5 checks:

1. **Specificity check:** Have I replaced every vague word with a specific one? ("Many" → "73%" / "Soon" → "by Friday")
2. **Proof check:** Does every claim have a number, name, or example next to it?
3. **Believability check:** Would I believe this if I read it cold? Or does it sound like marketing?
4. **Pace check:** Read it out loud. Where does the rhythm break? Fix that.
5. **Cut check:** Can I cut 20% without losing meaning? If yes, cut.

If a draft fails any check, rewrite that section.

---

## The Master Prompt

Paste this into Claude when writing any new piece of copy:

```
Act as a direct response copywriter using the 4-step Schwartz/Georgi/
Halbert/Bencivenga process.

PRODUCT: [what]
AUDIENCE: [who, in detail]
OFFER: [price, terms, bonus, guarantee]
GOAL: [click, opt-in, sale, call booked]
FORMAT: [Facebook ad / VSL / email / sales page / headline]
LENGTH: [word count or seconds]

Step 1 (Schwartz): Identify awareness level + hook strategy.
Step 2 (Georgi): Fill in RMBC (Research, Market, Big Idea, Concept).
Step 3 (Halbert): Write 5 hook variations using friend-to-friend voice.
Step 4 (Bencivenga): Run 5 validation checks. Mark anything that fails.

After all 4 steps, output the final draft.

Voice rules:
- No em dashes
- No triple structures ("It's not X, it's Y, it's Z")
- No corporate words (utilize, leverage, optimize, robust, seamless)
- No "AI tells" (overly polished transitions, perfect symmetry)
- Write like the person actually talks
```

---

## Where The Output Lives

Save final copy to `.brain/copy/[client-or-product]/[format]/[date]-[hook-version].md`.

Tag it for future swipe file mining.

---

## What This Is NOT

- Not a "make it sound better" tool. Use it to write from scratch.
- Not for branding copy. This is for direct response (clicks, opt-ins, sales).
- Not a hook generator. It's the full pipeline. Hooks come from Step 3.

---

*Copywriter Lite v1.0 — Master this before adding more frameworks. Ralph Wiggum 8-pass loop is the next level.*
