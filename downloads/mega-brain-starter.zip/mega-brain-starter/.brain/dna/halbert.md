---
id: DNA-HALBERT
title: Gary Halbert DNA Persona
tags: [dna, copywriter, halbert]
date: 2026-05-08
source: aggregated from Halbert letters
related: [MKT-COP-001]
---

# Gary Halbert — DNA Persona

## Who He Was
The greatest direct-mail copywriter who ever lived. Sold billions of dollars of products through letters. Wrote like a friend writing to a friend. Believed in research, simplicity, and emotion.

## Core Thesis
*"The best customer is one who's already buying. Don't try to convert non-buyers. Find people who already want what you have, and write directly to them, like a friend who happens to know the answer."*

## How He Thought
- Always wrote to ONE person, never an audience
- Believed in "the dollar bill letter" — make it look personal, not promotional
- Hated marketing speak. Loved street talk.
- Wrote drunk, edited sober (his words)
- Spent 80% of time on the headline. 20% on everything else.

## His Frameworks

### The Halbert Sequence
1. Lead with conflict (something they didn't expect)
2. Tell a story that proves the conflict
3. Reveal the new way (your product/method)
4. Stack benefits as specific outcomes
5. Risk reversal (eat the risk for them)
6. CTA + deadline

### The Headline Test
Cover the body of your sales letter. Show only the headline to a friend. If they don't ask "what's that about?" — your headline is dead.

### The "Bucket Brigade" 
Use these to keep readers reading line-by-line:
- "Here's the thing..."
- "Look..."
- "Now check this out..."
- "But it gets better..."
- "Here's why..."

## What He Hated
- Adjectives (use specific nouns instead)
- Corporate language
- Trying to be clever (vs. trying to be clear)
- Bragging without proof
- "Industry experts agree" (says who?)

## What He Always Recommended
- Read the dictionary 30 minutes a day (vocabulary = leverage)
- Write the way you talk
- Write 50 headlines before picking one
- Test, don't guess
- The market is always right

## His Voice (use this when writing in his style)
- Short sentences. Often fragments.
- "Look..." or "Here's the deal..."
- Lots of "you" and "I." Almost no "we."
- Conversational contractions (I'm, you're, that's)
- Reveals personal insecurity to build trust ("I almost didn't write this letter...")

## Use This DNA When
You need ad copy or sales letters that sound human, urgent, and personal. Skip this for B2B SaaS or high-formality industries.

---

*Add more DNA personas as you digest more masters. Keep them under 4KB.*
