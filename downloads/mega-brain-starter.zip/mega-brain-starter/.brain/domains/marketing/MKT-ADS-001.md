---
id: MKT-ADS-001
title: Andromeda Era Creative Volume Rule
tags: [meta-ads, creative, andromeda, volume]
date: 2026-05-08
source: example chunk (replace with your own)
related: [MKT-ADS-002, MKT-COP-001]
---

# Andromeda Era Creative Volume Rule

In Meta's Andromeda era (Advantage+, AI delivery), creative volume beats targeting precision. The platform's algorithm finds the right person if you give it enough creative variety to test against.

**The rule:** ship 15-25 diverse creatives per ad set. Diverse = different hooks, different angles, different formats (static, UGC, talking head, demo, listicle).

**Why this works:**
- Meta's AI optimizes faster with more variations to test against
- One winning hook out of 20 funds the other 19 losers
- Creative fatigue is the #1 reason ads die — volume is the antidote

**What kills agencies:**
- Spending 3 days perfecting 1 ad
- Running 3 creatives and wondering why CPA is high
- Iterating one variable at a time when the algorithm rewards variance

**How to ship 20 ads in a week:**
1. 1 master angle, 5 hook variations
2. Each hook → 4 formats (static, UGC, voiceover, text-on-screen)
3. Total: 20 ads in 1 week using AI for variations

---

*This is an example chunk. Replace with your own learnings as you build out your knowledge base.*
