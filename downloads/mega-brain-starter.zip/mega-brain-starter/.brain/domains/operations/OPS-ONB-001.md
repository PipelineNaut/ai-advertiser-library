---
id: OPS-ONB-001
title: Client Onboarding 7-Day Sprint
tags: [onboarding, ops, sop]
date: 2026-05-08
source: example chunk (replace with your own)
related: [OPS-INT-001]
---

# Client Onboarding 7-Day Sprint

Every new client goes through the same 7-day onboarding. By Day 7, ads are live or you know exactly why they're not.

**Day 1: Kickoff**
- Send welcome email with calendar link for Day 2 strategy call
- Send onboarding intake form (business, audience, current ads, login access)

**Day 2: Strategy call (60 min)**
- Pull current funnel + ads
- Identify the #1 leak
- Set 30-day goal (specific number, not "growth")
- Agree on weekly reporting cadence

**Day 3-4: Asset gathering**
- Get full Meta access (Business Manager + page + ad account)
- Install/verify Pixel + CAPI + GA4
- Pull 90 days of historical ad data
- Audit landing page

**Day 5: Creative production**
- Write 5 ads using copywriter skill
- Generate 3 visuals or pull UGC samples
- Build campaign structure in Meta

**Day 6: QA + Launch prep**
- Internal QA on all assets
- Send to client for approval
- Schedule launch for tomorrow

**Day 7: Launch**
- Push live at 9am client local time
- Monitor first 4 hours
- Send "we're live" message with screenshots
- Set 7-day check-in

**What "done" looks like:** ads running, tracking working, client knows the plan.

---

*Replace with your own onboarding flow. Adapt the days to fit your service.*
