# 🧠 Knowledge Base Index

> Your agency's brain. Every chunk of valuable knowledge lives here, organized by domain. Search this file to find what you need before answering any question.

---

## 📊 Domains

### Marketing (`MKT`)
- `MKT-CHF` — Challenge funnels
- `MKT-WEB` — Webinars
- `MKT-VSL` — Video sales letters
- `MKT-ADS` — Ads & creative
- `MKT-COP` — Copywriting
- `MKT-FUN` — Funnel architecture
- `MKT-EMA` — Email sequences

### Operations (`OPS`)
- `OPS-SOP` — Standard operating procedures
- `OPS-ONB` — Client onboarding
- `OPS-INT` — Integrations (Pixel, CAPI, GA4)
- `OPS-RPT` — Reporting & deliverables

### Sales (`SAL`)
- `SAL-DIS` — Discovery scripts
- `SAL-CLO` — Closing scripts
- `SAL-OBJ` — Objection handling
- `SAL-PIP` — Pipeline management

### Finance (`FIN`)
- `FIN-PRI` — Pricing strategy
- `FIN-PNL` — P&L management
- `FIN-MET` — Metrics & unit economics

### Leadership (`LED`)
- `LED-STR` — Strategy
- `LED-DEC` — Decisions

---

## 🧬 Expert DNA

Personas of masters whose work has been digested into this brain:

- `dna/halbert.md` — Gary Halbert (direct mail king)
- `dna/schwartz.md` — Eugene Schwartz (Breakthrough Advertising)
- `dna/[expert].md` — Add yours

---

## 📥 Raw Material

`.brain/raw/` — drop new content here for processing through MEGA DIGESTIVE LITE.

---

## 🔍 How To Search

When asked any technical/strategic question:
1. Read this index.
2. Open the relevant domain folder.
3. Skim chunk titles.
4. Open the matching chunk.
5. Cite the chunk ID in your answer (e.g., `[MKT-CHF-001]`).

---

## ✅ Chunk Quality Standards

Every chunk must have:
- Unique ID (DOMAIN-CAT-NUM)
- Title (5 words or less)
- YAML frontmatter (id, title, tags, date, source, related)
- Max 4KB body
- At least 1 `related:` link to another chunk

---

*Edit this index every time you add a new category or domain.*
