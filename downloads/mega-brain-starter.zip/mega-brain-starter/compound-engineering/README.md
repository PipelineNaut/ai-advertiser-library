# 🏗️ Compound Engineering — The 4-Phase Framework

> A workflow for any task bigger than a day. Most agency owners skip planning, jump to execution, then pay for it on the back end. This framework forces you to invest where the leverage actually is.

---

## The Core Idea

For any non-trivial task, allocate your time like this:

```
PLAN     ████████████████ 40%
WORK     ████████ 20%
REVIEW   ████████ 20%
DOCUMENT ████████ 20%
```

Notice what's NOT here. There's no "execute first, plan after" rule. There's no "ship it, fix it later." Plan eats half the timeline. That's intentional.

---

## Why This Order Matters

### Plan (40%)
Most people give planning 5%. They get the mission wrong, the scope wrong, the order wrong. Then they spend 3x longer fixing it during work.

When you put 40% of time into planning, you understand the actual problem before lifting a finger. You catch dead ends in advance. You write the success criteria so you know when you're done.

### Work (20%)
Once the plan is right, work is fast. You're executing a clear path. No decisions to make mid-flight. No second-guessing.

20% feels short. It is. That's the point. If work takes longer than 20%, your plan was incomplete.

### Review (20%)
You almost never get it right on the first pass. Review is where you catch what work missed.

Read your output cold. Pretend you didn't write it. Find the holes. Fix them.

### Document (20%)
This is the part everyone skips. Big mistake.

Documenting is where the work compounds. You write down what you learned, what worked, what didn't. Next time you face a similar task, you read your own notes and skip 70% of the planning phase.

Skip documenting and you'll redo this same work in 3 months.

---

## When To Use This

Use the 4-phase framework for:
- New client onboarding (each one)
- Launching a new ad funnel
- Building a new SOP
- Hiring decisions
- Pricing changes
- Any project that takes more than 1 day

Don't use it for:
- Replying to an email
- Quick fixes to running campaigns
- 30-minute tasks

---

## The Phase-By-Phase Prompts

Use these with Claude when running the framework on a real task:

### Phase 1: Plan (40%)
Tell Claude:
> *"We're using compound engineering on this task. We're in the PLAN phase. Goal: [task]. Help me understand this problem completely before any execution. Cover: 1) what's the actual goal in one sentence, 2) what does success look like (specific criteria), 3) what could go wrong, 4) what's the dependencies, 5) what's the rough order of operations. Don't write any execution yet. Just plan."*

### Phase 2: Work (20%)
Tell Claude:
> *"PLAN is approved. Now we're in WORK phase. Execute the plan. No deviations. If you find a problem with the plan, stop and tell me. Don't improvise."*

### Phase 3: Review (20%)
Tell Claude:
> *"Work is done. Now we're in REVIEW phase. Read what we produced cold. Find: 1) what's missing, 2) what's weak, 3) what would a smart skeptic catch, 4) what would the client/market reject. Don't sugarcoat. Tell me what to fix."*

### Phase 4: Document (20%)
Tell Claude:
> *"Review is done. Now we're in DOCUMENT phase. Write a chunk for the brain covering: 1) what was the task, 2) what was the approach, 3) what worked, 4) what didn't, 5) what I'd do differently next time, 6) the reusable principle. Save to .brain/learnings/[YYYY-MM-DD]-[task].md."*

---

## Real Example

**Task:** Onboard new med spa client.

**Plan (40% = ~3 hours of a 1-day onboarding):**
- Goal: client launched profitably within 7 days
- Success: ads live, tracking working, $500+ first-week revenue
- Risks: pixel install fails, creative doesn't resonate, owner doesn't approve in time
- Dependencies: ad account access, creative assets, landing page
- Order: kickoff → assets → tracking → creative → QA → launch

**Work (20% = ~90 min):**
- Execute the plan as-is. No detours.

**Review (20% = ~90 min):**
- Pixel firing? CAPI working? Match rate >70%?
- Are creatives diverse enough (5+ angles)?
- Does the LP load in <3 seconds?

**Document (20% = ~90 min):**
- What was unique about this client (med spa, female-targeted, GLP-1 niche)
- What worked (compounded semaglutide angle hit)
- What didn't (LP form was too long, dropped 40% of traffic)
- Learnings → save as `.brain/onboarding-learnings/2026-05-08-medspa.md`

Total: 1 day. But this 1 day teaches you something the next med spa onboarding skips. That's compound.

---

## The Anti-Patterns

❌ **Skipping Plan:** "I know what to do, let's just start." This is how 1-day projects become 4-day projects.

❌ **Skipping Document:** "I'll remember." You won't. You'll redo the same research 6 weeks later.

❌ **Treating Review as a Formality:** "It looks good." Review hard. Find what's broken. Fix before shipping.

❌ **Padding Work:** "Just one more thing." When work takes more than 20%, your plan was wrong. Stop, replan, restart work.

---

## What This Unlocks

After 30 days of using compound engineering on every meaningful task, you'll notice:

- Your delivery quality goes up
- Your repeated tasks take less time (because of past Document phases)
- Your team can replicate your work (because the docs exist)
- Your weeks feel less reactive (because plans absorb the chaos)

That's the compound. Plan more, do less, ship better.

---

*Compound Engineering Framework v1.0. The 40/20/20/20 split is the floor, not the ceiling. For huge projects, make Plan even bigger.*
