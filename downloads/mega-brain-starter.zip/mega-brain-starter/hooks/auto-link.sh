#!/bin/bash
FILE="$1"

# Only run on chunks in .brain/domains/
if [[ "$FILE" != *".brain/domains/"* ]]; then
  exit 0
fi

# Extract tags from this chunk
TAGS=$(grep "^tags:" "$FILE" | sed 's/tags: //; s/[][,]//g')

# If related: is empty, find chunks with overlapping tags
RELATED_LINE=$(grep "^related:" "$FILE")
if [[ "$RELATED_LINE" == "related: []" ]] || [[ "$RELATED_LINE" == "related:" ]]; then
  echo "🔗 Empty related field. Search .brain/ for chunks with tags: $TAGS"
  echo "   Edit $FILE to add the most relevant chunk IDs."
fi

exit 0
