#!/bin/bash
FILE="$1"

# Only validate files in .brain/
if [[ "$FILE" != *".brain/"* ]] || [[ "$FILE" != *".md" ]]; then
  exit 0
fi

# Check for required frontmatter fields
for field in "id:" "title:" "tags:" "date:" "related:"; do
  if ! grep -q "^${field}" "$FILE"; then
    echo "❌ Missing field '${field}' in $FILE"
    exit 1
  fi
done

echo "✅ Chunk validated: $FILE"
exit 0
