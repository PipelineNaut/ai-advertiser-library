# 🪝 Hooks — Auto-Magic In The Background

> Hooks are scripts that fire automatically when Claude does certain things. Think of them as your AI's reflexes. They run without you asking. They keep your brain organized, validated, and synced.

---

## Why Hooks Matter For Agencies

Without hooks, you have to remember to:
- Link new chunks to related chunks
- Validate every chunk has proper frontmatter
- Save important learnings to memory
- Commit changes to git so nothing gets lost

You'll forget. Every time.

With hooks, all of that happens automatically. The brain stays organized. Knowledge compounds without your discipline.

---

## The 4 Hooks Every Agency Brain Needs

### 1. Auto-Link Chunks
**Triggers when:** you create a new file in `.brain/domains/`
**What it does:** scans the new chunk, finds related chunks already in the brain, auto-adds them to the `related:` field in frontmatter
**Why it matters:** every chunk needs at least 1 link. Without this hook, you'll create orphan chunks that the brain can't find later.

### 2. Validate Chunk Frontmatter
**Triggers when:** any `.md` file in `.brain/` is saved
**What it does:** checks the file has all required fields (id, title, tags, date, related). If anything's missing, blocks the save and tells you what to fix.
**Why it matters:** garbage in, garbage out. This hook keeps your knowledge base clean from day 1.

### 3. Auto-Save Learnings
**Triggers when:** Claude says something like "remember this" or finishes a major task
**What it does:** extracts the learning, saves it to your memory system as a properly tagged memory
**Why it matters:** Claude often discovers patterns mid-session. Without this hook, those patterns die when the session ends.

### 4. Auto-Commit
**Triggers when:** Claude finishes editing files and the session ends
**What it does:** runs `git add . && git commit -m "auto-sync [date]"` so your brain always has version history
**Why it matters:** if you ever need to roll back, you can. If your laptop dies, you don't lose 6 months of brain work.

---

## How Hooks Work In Claude Code

Hooks live in your `~/.claude/settings.json` under the `hooks` key. Each hook has:

- **Event** — what triggers it (PreToolUse, PostToolUse, Stop, UserPromptSubmit, etc.)
- **Matcher** — which tools or patterns to match (e.g., `Write` or `Edit`)
- **Command** — the script to run

The hook script can be a one-liner shell command or a path to a script file.

---

## The Hook Configurations

Drop these into your `~/.claude/settings.json`:

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Write|Edit",
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/validate-chunk.sh \"$CLAUDE_FILE_PATH\""
          },
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/auto-link.sh \"$CLAUDE_FILE_PATH\""
          }
        ]
      }
    ],
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/auto-commit.sh"
          },
          {
            "type": "command",
            "command": "bash ~/.claude/hooks/auto-save-learnings.sh"
          }
        ]
      }
    ]
  }
}
```

---

## The Hook Scripts

Place these in `~/.claude/hooks/`:

### validate-chunk.sh
```bash
#!/bin/bash
FILE="$1"

# Only validate files in .brain/
if [[ "$FILE" != *".brain/"* ]] || [[ "$FILE" != *".md" ]]; then
  exit 0
fi

# Check for required frontmatter fields
for field in "id:" "title:" "tags:" "date:" "related:"; do
  if ! grep -q "^${field}" "$FILE"; then
    echo "❌ Missing field '${field}' in $FILE"
    exit 1
  fi
done

echo "✅ Chunk validated: $FILE"
exit 0
```

### auto-link.sh
```bash
#!/bin/bash
FILE="$1"

# Only run on chunks in .brain/domains/
if [[ "$FILE" != *".brain/domains/"* ]]; then
  exit 0
fi

# Extract tags from this chunk
TAGS=$(grep "^tags:" "$FILE" | sed 's/tags: //; s/[][,]//g')

# If related: is empty, find chunks with overlapping tags
RELATED_LINE=$(grep "^related:" "$FILE")
if [[ "$RELATED_LINE" == "related: []" ]] || [[ "$RELATED_LINE" == "related:" ]]; then
  echo "🔗 Empty related field. Search .brain/ for chunks with tags: $TAGS"
  echo "   Edit $FILE to add the most relevant chunk IDs."
fi

exit 0
```

### auto-commit.sh
```bash
#!/bin/bash
cd "$CLAUDE_PROJECT_DIR" || exit 0

# Only commit if there are changes
if [[ -n $(git status -s) ]]; then
  git add .
  git commit -m "🧠 auto-sync: $(date '+%Y-%m-%d %H:%M')" --quiet
  echo "✅ Auto-committed brain changes"
fi
```

### auto-save-learnings.sh
```bash
#!/bin/bash
# Reads the last assistant message. If it contains "lesson:", "learning:", or 
# "pattern:", saves to memory.

# This is a placeholder. Real implementation needs claude-mem hooked in.
# For now, log the trigger.
echo "🧬 Auto-save check ran at $(date)"
```

---

## Install Steps

```bash
# 1. Create the hooks directory
mkdir -p ~/.claude/hooks

# 2. Copy the 4 scripts (from this pack) to ~/.claude/hooks/

# 3. Make them executable
chmod +x ~/.claude/hooks/*.sh

# 4. Add the hook configs (from this README) to ~/.claude/settings.json

# 5. Restart Claude Code
```

---

## Test Your Hooks

After install, create a new chunk that's missing the `related:` field. The validate hook should block the save and tell you what's missing.

If it doesn't fire, check:
- `chmod +x ~/.claude/hooks/*.sh`
- Hook scripts have proper shebang `#!/bin/bash`
- Settings.json is valid JSON (validate at jsonlint.com)
- You restarted Claude after editing settings

---

## What NOT To Hook

- Don't hook on every Read (will spam you)
- Don't hook destructive operations on Stop (could lose data)
- Don't make hooks that need network access (slow, fragile)

Keep hooks fast (under 2 seconds) and local (no API calls).

---

## What This Unlocks

Once hooks are running, your brain maintains itself. You write knowledge. The system organizes it. You commit nothing manually. The system commits for you. You forget to link chunks. The system reminds you.

That's the difference between a knowledge base and a self-improving brain.

---

*Hooks Pack v1.0. Add more hooks as your workflow develops. Keep each one focused on ONE job.*
