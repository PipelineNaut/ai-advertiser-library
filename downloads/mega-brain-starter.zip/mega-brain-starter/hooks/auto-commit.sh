#!/bin/bash
cd "$CLAUDE_PROJECT_DIR" || exit 0

# Only commit if there are changes
if [[ -n $(git status -s) ]]; then
  git add .
  git commit -m "🧠 auto-sync: $(date '+%Y-%m-%d %H:%M')" --quiet
  echo "✅ Auto-committed brain changes"
fi
