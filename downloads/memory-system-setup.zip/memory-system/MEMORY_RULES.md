# Memory Rules — Add To Your Global CLAUDE.md

> Drop this into `~/.claude/CLAUDE.md`. It teaches Claude how to use the memory system properly.

---

## 🧬 Memory System

You have a persistent, vector-based memory at `~/.claude-mem/archives/` powered by Chroma DB. Use it to remember critical context across sessions.

### When To Save Memories

Save automatically when you learn:
- **User profile**: who they are, their role, their goals
- **Feedback**: corrections, preferences, things they hate
- **Project state**: current work, decisions, blockers
- **External references**: where info lives (Slack, Stripe, etc.)

Save explicitly when the user says "remember this" or asks you to.

### When To Query Memories

Query at the start of any session that touches:
- A specific client or project mentioned before
- A topic the user has strong opinions about
- Anything where prior context might exist

### How To Search

```
mcp__claude-mem__chroma_query_documents(["[project-name] [topic]"])
```

**Critical rule:** always prefix queries with the project name. Otherwise memories cross-contaminate across projects.

### Format For Saving

Each memory must include:
- **Type**: user, feedback, project, or reference
- **Project**: which project this belongs to
- **Date**: absolute date (convert "Thursday" → "2026-05-15")
- **Body**: the actual content
- **Why** (for feedback/project): the reason this matters

### What NOT To Save

- Code patterns (read the codebase)
- Git history (use `git log`)
- Anything already in CLAUDE.md
- Conversation context that won't matter next session

### Verify Before Trusting

Memories can go stale. Before acting on a recalled memory, verify against current state. If it conflicts with reality, update the memory.

---

## Search Tips That Actually Work

✅ **Semantic intent**: "implementing oauth" beats "oauth implementation function code"
✅ **Project prefix**: "my-agency client X" not "client X"
✅ **Temporal search**: "my-agency 2026-04-12 onboarding" finds memories from that week
✅ **Multiple queries**: search 2-3 different phrasings for better coverage

❌ **Don't use complex filters** ($and / $or cause errors)
❌ **Don't compare timestamps** (Chroma stores them as strings)
❌ **Don't mix project filters in where clause** (causes "Error finding id")

---

## The 4 Memory Types

### User
Who they are, what they do, how they collaborate.
*Save when:* you learn anything about their role, preferences, or perspective.

### Feedback
How they want you to behave. Especially what they DON'T want.
*Save when:* they correct you ("no, not like that") or confirm something worked ("yes exactly").
*Format:* lead with the rule, then **Why:** and **How to apply:** lines.

### Project
Current state of ongoing work. Who's doing what, why, by when.
*Save when:* you learn about goals, deadlines, decisions, blockers.
*Convert relative dates to absolute.*

### Reference
Pointers to where information lives in external systems.
*Save when:* user mentions a tool, dashboard, or external system that holds info.

---

## Self-Cleanup

Update or delete memories when:
- They turn out to be wrong
- They become outdated
- The user explicitly asks you to forget

Never write duplicates. Always check for existing memories before writing a new one.
