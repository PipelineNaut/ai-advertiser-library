# 🧬 Memory System Setup (claude-mem)

> Persistent memory across every Claude session. Your AI remembers your business, your clients, your decisions. No more starting over.

---

## What This Does

By default, Claude has goldfish memory. Open a new chat and it forgets everything. Useless for an agency.

claude-mem fixes that. It saves every important thing from your sessions into a vector database. Next time you open Claude, it pulls relevant memories automatically.

You ask: "what's the deal with that med spa client we onboarded in march?"
Claude pulls the memory, answers like it remembers. Because it does.

---

## What Gets Remembered

- Your business details (agency name, niches, voice)
- Client information (who they are, what they sell, what's working)
- Decisions you made and why
- Feedback you gave Claude (what to do, what not to do)
- Patterns and learnings

---

## Install (5 minutes)

### Step 1: Install claude-mem
```bash
npm install -g @anthropic/claude-mem
```

### Step 2: Initialize the database
```bash
claude-mem init
```
This creates `~/.claude-mem/` with a Chroma vector database inside.

### Step 3: Wire it into your CLAUDE.md
Add this section to your global `~/.claude/CLAUDE.md`:

```markdown
## 🧠 Memory System Quick Reference

### Search Your Memories
- Semantic search: `mcp__claude-mem__chroma_query_documents(["search terms"])`
- Always include project name: `["my-agency feature authentication"]`
- Include dates for temporal search: `["my-agency 2026-04-12 client onboarded"]`

### Storage
- Collection: `claude_memories`
- Archives: `~/.claude-mem/archives/`
```

### Step 4: Test it
Open Claude Code. Tell it something:
> *"remember that my favorite client is [client name] and they pay $5K retainer"*

Close the session. Open a new one. Ask:
> *"who's my favorite client?"*

If it answers correctly, memory is working.

---

## How To Use It Daily

### Save important things
When you learn something or make a decision, just say:
> *"remember this: [the thing]"*

It auto-saves to the right memory bucket.

### Query memories
When you need context from before:
> *"check memory for everything about [topic / client / decision]"*

### Forget things
When info is wrong or outdated:
> *"forget what I said about [topic]"*

---

## The Memory Hierarchy

Memory has 4 types:

| Type | What Goes Here | Example |
|------|---------------|---------|
| **User** | Who you are, your role, preferences | "Rodrigo runs a performance marketing agency" |
| **Feedback** | How to behave with you | "Don't use em dashes" |
| **Project** | Current state of work | "Med spa client launched campaign April 12" |
| **Reference** | Where info lives in external systems | "Client billing is in Stripe" |

Tag memories with their type so retrieval is clean.

---

## What NOT To Save

- Code patterns (those are in the codebase)
- Git history (use `git log`)
- Things already in CLAUDE.md
- Ephemeral session details

Save what would help you in 6 months. Skip everything else.

---

## Common Issues

**"Error finding id"** — your where filter is too complex. Use simple semantic search instead of filters.

**Memories getting mixed across projects** — always include project name in your query: `["my-agency client question"]` not just `["client question"]`.

**Stale memories** — verify against current state before acting. If a memory says "client X pays $5K" and reality is now $7K, update the memory.

---

## Why This Matters For Agencies

Without memory:
- You re-explain your business every session
- Claude forgets what worked for client A
- Every onboarding starts from zero
- Knowledge stays in your head, not the system

With memory:
- Claude remembers every client
- Decisions compound (you don't repeat the same mistakes)
- New team members get up to speed faster (the memory teaches them)
- Your agency gets smarter every week, not just every quarter

---

*claude-mem v1.0 setup. Pair with the MEGA Digestive system for max compound.*
